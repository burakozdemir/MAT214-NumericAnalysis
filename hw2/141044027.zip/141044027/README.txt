141044027
Burak Özdemir
Sayısal ANALİZ 2. Ödev

::ÖDEV 2 PARTTAN OLUŞMUŞTUR.::

PART 1 ==> Java projesi olarak vardır.
        ==> Main class vardır ve src dizi içerisindedir
        ==> Gesp ve JCB modları ile denklemın koklerıne yakınsama yapar .

Part 2 ==> Denklem kağıda çözülüp program ile pdf haline getirilmiştir.
        ==> 3 sayfalık bir pdftir.
        
