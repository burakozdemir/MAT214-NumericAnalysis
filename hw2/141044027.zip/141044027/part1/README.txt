MakeFile Komutlar:

6.2 1c.txt için(GESP) ==>make 6.2-1c
7.3 1a.txt için(JCB) ==>make 7.3-1a
7.3 1b.txt için(JCB) ==>make 7.3-1b
